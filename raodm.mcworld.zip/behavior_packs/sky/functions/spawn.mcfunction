# reset time
scoreboard players set global time 0

# random bằng @r
execute @r run fill ~-5 ~-1 ~-5 ~4 ~-1 ~4 stone
execute @r run fill ~-5 ~-2 ~-5 ~4 ~-2 ~4 dirt
execute @r run fill ~-5 ~-3 ~-5 ~4 ~-3 ~4 sand

execute @r run fill ~-5 ~-1 ~-5 ~4 ~-1 ~4 iron_ore
execute @r run fill ~-5 ~-2 ~-5 ~4 ~-2 ~4 coal_ore
execute @r run fill ~-5 ~-3 ~-5 ~4 ~-3 ~4 gravel

execute @r run fill ~-5 ~-1 ~-5 ~4 ~-1 ~4 diamond_ore
execute @r run fill ~-5 ~-2 ~-5 ~4 ~-2 ~4 gold_ore
execute @r run fill ~-5 ~-3 ~-5 ~4 ~-3 ~4 cobblestone