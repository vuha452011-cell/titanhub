gamerule doDaylightCycle true
scoreboard objectives add time dummy

# tạo đảo 10x10
fill ~-5 ~ ~-5 ~4 ~ ~4 grass_block
fill ~-5 ~-1 ~-5 ~4 ~-20 ~4 air