scoreboard players add global time 1

execute if score global time matches 24000 run function spawn